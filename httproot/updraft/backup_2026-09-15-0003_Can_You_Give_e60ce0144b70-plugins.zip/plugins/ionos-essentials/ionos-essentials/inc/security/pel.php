<?php

namespace ionos\essentials\security;

defined('ABSPATH') || exit();

\add_action('login_init', function () {
  \remove_filter('authenticate', 'wp_authenticate_email_password', 20);
  \add_filter(
    'authenticate',
    function ($user, $username) {
      if (strpos($username, '@') !== false) {
        return new \WP_Error(
          'email_login_inactive',
          __('<strong>Error</strong>: The login with an email address is deactivated for this website. Please use your username instead.', 'ionos-essentials')
        );
      }

      return $user;
    },
    200,
    2
  );
});
