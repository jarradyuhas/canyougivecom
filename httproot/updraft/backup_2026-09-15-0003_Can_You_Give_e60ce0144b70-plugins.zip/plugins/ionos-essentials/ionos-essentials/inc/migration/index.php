<?php

/*
 * the migration logic uses an auto loaded option to store the last installed version data
 * this way we can run the migration logic only once after the plugin was installed or updated
 *
 * we don't use the register_activation_hook and upgrader_process_complete hooks to be mu-plugin and stretch compliant
 * in both cases we dont get notified this way.
 * we use instead the admin_init hook to check if the plugin was installed/updated.
 * to make it more efficient we use configure the option to be autoloaded
 */

namespace ionos\essentials\migration;

use function ionos\essentials\dashboard\install_plugin_from_url;

defined('ABSPATH') || exit();

define('IS_LOCAL', wp_get_environment_type() === 'local');

use const ionos\essentials\PLUGIN_FILE;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION_CREDENTIALS_CHECKING;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION_DEFAULT;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION_MAIL_NOTIFY;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION_PEL;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION_XMLRPC;

/*
 * wp option where the installation data is stored
 * the value is a associative array with keys from WP_OPTION_LAST_INSTALL_DATA_KEY_* constants
 * we use a array to be able to store multiple values in the future
 */

const WP_OPTION_LAST_INSTALL_DATA = 'ionos-essentials-last-install-data';

// key to store the plugin version in the installation data
const WP_OPTION_LAST_INSTALL_DATA_KEY_PLUGIN_VERSION = 'plugin-version';

/*
 * we hook our migration into admin-init to check if we were installed/updated
 * and if so, we run the migration.
 *
 * Attention: if our plugin once will take effect in published posts, we should hook into
 * 'init' instead of 'admin-init' to make sure the migration runs always.
 */
\add_action('admin_init', __NAMESPACE__ . '\_install', 1);

// can be left off if no uninstall logic is needed
\register_uninstall_hook(__FILE__, __NAMESPACE__ . '\_uninstall');

function _uninstall()
{
  // if you want to keep it, you can remove the following line
  // keeping it will bloat the wordpress installation load time even if the plugin is not installed anymore
  \delete_option(WP_OPTION_LAST_INSTALL_DATA);

  // do whatever is needed to cleanup data of this plugin when it gets uninstalled
}

function _install()
{
  $last_install_data      = \get_option(WP_OPTION_LAST_INSTALL_DATA);
  // default for first time activation: "0.0.0"
  $last_installed_version = $last_install_data[WP_OPTION_LAST_INSTALL_DATA_KEY_PLUGIN_VERSION] ?? '0.0.0';
  $current_version        = \get_plugin_data(PLUGIN_FILE)['Version'];

  $current_install_data = [
    WP_OPTION_LAST_INSTALL_DATA_KEY_PLUGIN_VERSION => $current_version,
  ];

  switch (true) {
    // plugin data match current version
    case version_compare($last_installed_version, $current_version, '=='):
      // nothing to do
      return;

    case version_compare($last_installed_version, '1.0.0', '<'):

      // keep consent for ionos loop to use it later on in dashboard
      $ionos_loop_consent_given = \get_option('ionos_loop_consent', false);

      $plugins_to_remove = [
        'ionos-loop/ionos-loop.php',
        'ionos-journey/ionos-journey.php',
        'ionos-navigation/ionos-navigation.php',
      ];
      \deactivate_plugins($plugins_to_remove);
      \add_action('shutdown', fn () => \delete_plugins($plugins_to_remove));

      // re add ionos loop consent data
      \add_option('ionos_loop_consent', $ionos_loop_consent_given);

      // install the performance plugin for all non stretch spaces
      if (! defined('IONOS_IS_STRETCH')                                              &&
      ! is_plugin_active('ionos-performance/ionos-performance.php')                  &&
      ! defined('IS_LOCAL')) {
        install_plugin_from_url(
          'https://s3-eu-central-1.ionoscloud.com/web-hosting/ionos-group/ionos-performance.latest.zip'
        );
        \activate_plugin('ionos-performance/ionos-performance.php');
      }

      // initialize wpscan results empty
      \set_transient('ionos_wpscan_last_scan', time());
      \set_transient('ionos_wpscan_issues', []);

      // no break because we want to run all migrations sequentially
    case version_compare($last_installed_version, '1.0.4', '<'):
      \update_option('ionos_migration_step', 1);
      // no break
    case version_compare($last_installed_version, '1.0.9', '<'):
      // deactivate and uninstall the ionos-assistant plugin
      \deactivate_plugins('ionos-assistant/ionos-assistant.php');
      \add_action('shutdown', fn () => \delete_plugins(['ionos-assistant/ionos-assistant.php']));
      update_plugin('ionos-marketplace/ionos-marketplace.php', false);
      \update_option('ionos_migration_step', 2);
      // no break
    case version_compare($last_installed_version, '1.1.0', '<'):
      if (array_key_exists('ionos-security/ionos-security.php', \get_plugins())) {
        \deactivate_plugins('ionos-security/ionos-security.php');
        \add_action('shutdown', fn () => \delete_plugins(['ionos-security/ionos-security.php']));
        \set_transient('ionos_security_migrated_notice_show', true, 3 * MONTH_IN_SECONDS);
      }

      // "ionos_essentials_security_off" is set for all bk customers that got essentials rolled out but they didnt have security plugin
      // for them we want all security features to be disabled

      if (\get_option('ionos_essentials_security_off')) {
        $xmlrpc_guard_enabled      = false;
        $pel_enabled               = false;
        $credentials_check_enabled = false;
        $wpscan_mail_notification  = false;
        \delete_option('ionos_essentials_security_off');
      } else {
        $ionos_security            = \get_option('ionos-security', []);
        $xmlrpc_guard_enabled      = (bool) ($ionos_security['xmlrpc_guard_enabled'] ?? IONOS_SECURITY_FEATURE_OPTION_DEFAULT[IONOS_SECURITY_FEATURE_OPTION_XMLRPC]);
        $pel_enabled               = (bool) ($ionos_security['pel_enabled'] ?? IONOS_SECURITY_FEATURE_OPTION_DEFAULT[IONOS_SECURITY_FEATURE_OPTION_PEL]);
        $credentials_check_enabled = (bool) ($ionos_security['credentials_check_enabled'] ?? IONOS_SECURITY_FEATURE_OPTION_DEFAULT[IONOS_SECURITY_FEATURE_OPTION_CREDENTIALS_CHECKING]);
        $wpscan_mail_notification  = (bool) ($ionos_security['wpscan_mail_notification'] ?? IONOS_SECURITY_FEATURE_OPTION_DEFAULT[IONOS_SECURITY_FEATURE_OPTION_MAIL_NOTIFY]);
      }

      \delete_option('ionos-security');
      $security_options                                                     = IONOS_SECURITY_FEATURE_OPTION_DEFAULT;
      $security_options[IONOS_SECURITY_FEATURE_OPTION_XMLRPC]               = $xmlrpc_guard_enabled;
      $security_options[IONOS_SECURITY_FEATURE_OPTION_PEL]                  = $pel_enabled;
      $security_options[IONOS_SECURITY_FEATURE_OPTION_CREDENTIALS_CHECKING] = $credentials_check_enabled;
      $security_options[IONOS_SECURITY_FEATURE_OPTION_MAIL_NOTIFY]          = $wpscan_mail_notification;

      \add_option(IONOS_SECURITY_FEATURE_OPTION, $security_options, '', true);
      // no break
    case version_compare($last_installed_version, '1.4.6', '<='):
      \update_option('ionos_wpscan_issues_sent_to_user', \get_transient('ionos_wpscan_issues_sent_to_user'), []);
  }
  \update_option(WP_OPTION_LAST_INSTALL_DATA, $current_install_data, true);
}

function update_plugin($plugin_slug, $activate = true)
{
  if (\current_user_can('update_plugins')) {
    include_once ABSPATH . 'wp-admin/includes/plugin.php';
    include_once ABSPATH . 'wp-admin/includes/update.php';
    include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

    \wp_update_plugins();

    $upgrader = new \Plugin_Upgrader(new \WP_Ajax_Upgrader_Skin());

    $upgrader->upgrade($plugin_slug);
    if ($activate) {
      \activate_plugin($plugin_slug);
    }
  }
}
