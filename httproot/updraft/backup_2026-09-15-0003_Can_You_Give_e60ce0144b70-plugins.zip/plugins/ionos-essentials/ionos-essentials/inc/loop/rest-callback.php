<?php

namespace ionos\essentials\loop;

defined('ABSPATH') || exit();

require_once __DIR__ . '/../dashboard/blocks/next-best-actions/index.php';
require_once __DIR__ . '/../dashboard/blocks/next-best-actions/class-nba.php';

use ionos\essentials\dashboard\blocks\next_best_actions\NBA;
use ionos\essentials\Tenant;
use const ionos\essentials\dashboard\blocks\next_best_actions\OPTION_IONOS_ESSENTIALS_NBA_ACTIONS_SHOWN;
use const ionos\essentials\dashboard\blocks\next_best_actions\OPTION_IONOS_ESSENTIALS_NBA_SETUP_COMPLETED;

const IONOS_LOOP_EVENTS_OPTION = 'ionos-loop-events';
const IONOS_LOOP_CLICKS_OPTION = 'ionos-loop-clicks';
const IONOS_LOOP_MAX_EVENTS    = 200;

function _rest_loop_callback(): \WP_REST_Response
{

  \add_option(IONOS_LOOP_DATACOLLECTOR_LAST_ACCESS, time());

  $core_data = [
    'version'       => '2.0',
    'hosting'       => _get_hosting(),
    'supplier'      => 'ionos-essentials',
    'wordpress'     => [
      'user_data'           => \count_users('memory'),
      'active_theme'        => _get_active_theme(),
      'plugins'             => _get_plugins(),
      'posts'               => _get_posts_and_pages(),
      'comments'            => _get_comments(),
      'uploads'             => _get_uploads(),
      'installed_themes'    => count(\wp_get_themes()),
      'installed_plugins'   => count(\get_plugins()),
      'permalink_structure' => \get_option('permalink_structure', ''),
      'siteurl'             => \get_option('siteurl', ''),
      'home'                => \get_option('home', ''),
    ],
    'vulnerabilities' => \get_transient('ionos_wpscan_issues'),
    'events'          => \get_option(IONOS_LOOP_EVENTS_OPTION, []),
    'clicks'          => \get_option(IONOS_LOOP_CLICKS_OPTION, []),

    'plugin_data' => [
      'ionos-essentials'    => [
        'dashboard'   => _get_dashbord_data(),
        'security'    => \get_option(\ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION, []),
        'maintenance' => \ionos\essentials\maintenance_mode\is_maintenance_mode(),
      ],
      'extendify' => [
        'extendify_onboarding_completed' => (bool) \get_option('extendify_onboarding_completed', null),
      ],
      'mcp' => [
        'settings' => \get_option('wordpress_mcp_settings', false),
        'tracking' => \get_option('ionos_loop_mcp_tracking', []),
      ],
    ],
  ];

  \delete_option(IONOS_LOOP_EVENTS_OPTION);
  \delete_option(IONOS_LOOP_CLICKS_OPTION);

  return \rest_ensure_response($core_data);
}

function _rest_loop_click_callback(\WP_REST_Request $request): \WP_REST_Response
{
  $body = $request->get_json_params();

  if (! isset($body['anchor'])) {
    return \rest_ensure_response([
      'error' => 'no anchor',
    ]);
  }

  $key = sanitize_text_field($body['anchor']);

  $data = \get_option(IONOS_LOOP_CLICKS_OPTION, []);
  if (! is_array($data)) {
    $data = [];
  }

  $data[$key] = isset($data[$key]) ? $data[$key] + 1 : 1;

  \update_option(IONOS_LOOP_CLICKS_OPTION, $data);

  return \rest_ensure_response([]);
}

function _rest_sso_click_callback(\WP_REST_Request $request): \WP_REST_Response
{
  // Store the current timestamp when SSO button is clicked
  \update_option(IONOS_LOOP_SSO_CLICK_OPTION, time());

  return \rest_ensure_response([
    'success' => true,
  ]);
}

function _get_dashbord_data(): array
{
  $data = [
    'nba_status'                                => [],
    OPTION_IONOS_ESSENTIALS_NBA_SETUP_COMPLETED => \get_option(OPTION_IONOS_ESSENTIALS_NBA_SETUP_COMPLETED, null),
  ];

  $nba_status = \get_option(NBA::OPTION_STATUS_NAME, []);
  foreach ($nba_status as $key => $value) {
    $data['nba_status'][$key] = join(',', array_keys($value));
  }

  $actions_shown = \get_option(OPTION_IONOS_ESSENTIALS_NBA_ACTIONS_SHOWN, []);
  foreach ($actions_shown as $value) {
    if (! array_key_exists($value, $data['nba_status'])) {
      $data['nba_status'][$value] = null;
    }
  }

  return $data;
}

function _get_hosting(): array
{
  return [
    'locale'               => \get_locale(),
    'blog_public'          => (bool) \get_option('blog_public'),
    'market'               => _get_market(),
    'tenant'               => Tenant::get_slug(),
    'core_version'         => \get_bloginfo('version'),
    'php_version'          => PHP_VERSION,
    'instance_created'     => _get_instance_creation_date(),
    'ssl_type'             => \ionos\essentials\get_ssl_type(),
    'hostname'             => \gethostname() ?: '',
  ];
}

function _get_market(): string
{
  return strtolower(\get_option(Tenant::get_slug() . '_market', 'de'));
}

function _get_instance_creation_date(): ?int
{
  $saved_value = \get_option('instance_creation_date');

  if ($saved_value && is_numeric($saved_value) && $saved_value > 946684800) {
    return (int) $saved_value;
  }

  $first_user        = get_users([
    'number' => 1,
  ]);
  $timestamp = strtotime($first_user[0]->user_registered . ' UTC');
  \update_option('instance_creation_date', $timestamp);
  return $timestamp;
}

function _get_active_theme(): array
{
  $current_theme = \wp_get_theme();

  $parent_theme_slug = $current_theme->parent() ? $current_theme->parent()
    ->get_stylesheet() : null;

  $auto_update_themes = \get_site_option('auto_update_themes', []);
  $current_theme_slug = $current_theme->get_stylesheet();
  $auto_update        = in_array($current_theme_slug, $auto_update_themes, true);

  return [
    'id'                => $current_theme_slug,
    'version'           => $current_theme->get('Version'),
    'parent_theme_slug' => $parent_theme_slug,
    'auto_update'       => $auto_update,
  ];
}

function _get_plugins(): array
{
  if (! function_exists('get_plugins')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
  }
  $all_plugins    = \get_plugins();
  $active_plugins = \get_option('active_plugins', []);
  $auto_updates   = \get_site_option('auto_update_plugins', []);

  $plugins_data = [];

  foreach ($all_plugins as $plugin_slug => $plugin_data) {
    $plugins_data[] = [
      'plugin_slug' => $plugin_slug,
      'version'     => $plugin_data['Version'],
      'auto_update' => in_array($plugin_slug, $auto_updates),
      'active'      => in_array($plugin_slug, $active_plugins),
    ];
  }

  return $plugins_data;
}

function _get_posts_and_pages(): array
{
  $post_counts = \wp_count_posts('post');
  $page_counts = \wp_count_posts('page');

  $posts_data = [
    [
      'type'  => 'post',
      'count' => (int) $post_counts->publish,
    ],
    [
      'type'  => 'page',
      'count' => (int) $page_counts->publish,
    ],
  ];

  return $posts_data;
}

function _get_comments(): array
{
  $comments_data = [];

  $comments_data['total'] = array_sum((array) \wp_count_comments());

  $comments_data['comments_active'] = \get_option('default_comment_status') ? true : false;

  return $comments_data;
}

function _get_uploads(): array
{
  $uploads_dir = \wp_get_upload_dir();
  $basedir     = $uploads_dir['basedir'];

  $file_count = 0;
  $size       = 0;

  if (! is_dir($basedir)) {
    return [
      'file_count' => 0,
      'size'       => '0',
    ];
  }

  $iterator = new \RecursiveIteratorIterator(
    new \RecursiveDirectoryIterator($basedir, \RecursiveDirectoryIterator::SKIP_DOTS)
  );

  foreach ($iterator as $file) {
    if ($file->isFile()) {
      $file_count++;
      $size += $file->getSize();
    }
  }

  return [
    'file_count' => $file_count,
    'size'       => $size,
  ];
}
