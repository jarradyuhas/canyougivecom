<?php

namespace ionos\essentials\wpscan;

defined('ABSPATH') || exit();

use ionos\essentials\Tenant;
use function ionos\essentials\_is_plugin_active;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION;
use const ionos\essentials\security\IONOS_SECURITY_FEATURE_OPTION_MAIL_NOTIFY;

class WPScan
{
  /**
   * @var mixed[]|bool
   */
  private $issues;

  private ?string $error = null;

  public function __construct()
  {
    $this->issues = \get_transient('ionos_wpscan_issues');

    if (false === $this->issues || ! is_array($this->issues)) {
      $this->get_new_middleware_data();

      $this->maybe_send_email();
    }

    if (0 < count($this->get_issues())) {
      \add_action('admin_notices', [$this, 'admin_notice']);
      \add_action('after_plugin_row', [$this, 'add_plugin_issue_notice'], 10, 3);
    }

    \add_action('admin_footer', [$this, 'add_theme_issues_notice']);
    \add_action('admin_footer', [$this, 'add_issue_on_plugin_install']);
    \add_action('admin_footer', [$this, 'add_issue_on_theme_install']);
    \add_action('admin_enqueue_scripts', [$this, 'remove_notice_during_plugin_deletion']);

    \add_action('upgrader_process_complete', function () {
      \delete_transient('ionos_wpscan_issues');
    }, 10, 2);
  }

  /**
   * @return mixed[]
   */
  public function get_issues($filter = null): array
  {
    // Filter out issues for plugins/themes that are not installed
    $all_slugs    = $this->get_installed_slugs();
    $this->issues = array_filter($this->issues, fn ($issue) => in_array($issue['slug'], $all_slugs, true));

    // update the update information
    foreach ($this->issues as &$issue) {
      if (null === $issue['update']) {
        $issue['update'] = $this->is_update_available($issue['slug']);
      }
    }

    if (null === $filter) {
      return $this->issues;
    }

    return array_filter(
      $this->issues ?? [],
      fn ($issue) => ('critical' === $filter) ? 7 < $issue['score'] : 7 >= $issue['score']
    );
  }

  public function admin_notice(): void
  {
    global $current_screen;

    $brand = Tenant::get_slug();
    if (! isset($current_screen->id) || in_array($current_screen->id, ['toplevel_page_' . $brand], true)) {
      return;
    }

    printf(
      '<div class="notice notice-alt ionos-issues-found-adminbar %s"><p>%s: %d %s. <a href="%s">%s.</a></p></div>',
      (0 < count($this->get_issues('critical'))) ? 'notice-error' : 'notice-warning',
      \esc_html__('Vulnerability scan', 'ionos-essentials'),
      count($this->get_issues()),
      (1 === count($this->get_issues())) ? \esc_html__('issue found', 'ionos-essentials') :
      \esc_html__('issues found', 'ionos-essentials'),
      \esc_url(admin_url('admin.php?page=' . $brand . '#tools')),
      \esc_html__('More information', 'ionos-essentials')
    );
  }

  public function add_issue_on_theme_install(): void
  {
    $screen = get_current_screen();
    if (! $screen || ('theme-install' !== $screen->id)) {
      return;
    }

    \wp_enqueue_script('ionos-essentials-theme-install');

    \wp_localize_script(
      'ionos-essentials-theme-install',
      'ionosWPScanThemes',
      [
        'issues'  => $this->get_issues(),
        'nonce'   => \wp_create_nonce('ionos-wpscan-instant-check'),
      ]
    );
  }

  public function add_issue_on_plugin_install(): void
  {
    $screen = get_current_screen();
    if (! $screen || ('plugin-install' !== $screen->id)) {
      return;
    }

    \wp_enqueue_script('ionos-essentials-plugin-install');

    \wp_localize_script(
      'ionos-essentials-plugin-install',
      'ionosWPScanPlugins',
      [
        'issues'  => $this->get_issues(),
        'nonce'   => \wp_create_nonce('ionos-wpscan-instant-check'),
      ]
    );
  }

  public function add_theme_issues_notice(): void
  {
    $screen = get_current_screen();
    if (! $screen || ('themes' !== $screen->id)) {
      return;
    }

    $issues = array_filter($this->get_issues(), fn ($issue) => 'theme' === $issue['type']);

    if (0 === count($issues)) {
      return;
    }

    \wp_enqueue_script('ionos-essentials-theme-overview');

    \wp_localize_script(
      'ionos-essentials-theme-overview',
      'ionosWPScanThemes',
      [
        'slugs' => array_column($issues, 'slug'),
        'brand' => Tenant::get_slug(),
      ]
    );
  }

  public function remove_notice_during_plugin_deletion(): void
  {
    $screen = get_current_screen();

    if (! $screen || 'plugins' !== $screen->id) {
      return;
    }

    \wp_enqueue_script('ionos-essentials-plugin-delete');

    \wp_localize_script(
      'ionos-essentials-plugin-delete',
      'ionosWPScanPlugins',
      [
        'issues'  => $this->get_issues(),
        'nonce'   => \wp_create_nonce('ionos-wpscan-instant-check'),
      ]
    );
  }

  public function add_plugin_issue_notice($plugin_file, array $plugin_data, $status): void
  {

    $screen = get_current_screen();
    if (! $screen || 'plugins' !== $screen->id) {
      return;
    }
    $paths = array_column($this->get_issues(), 'path');
    if (! in_array($plugin_file, $paths, true)) {
      return;
    }
    echo '<script>
      document.addEventListener("DOMContentLoaded", function() {
        const row = document.querySelector("tr[data-plugin=\'' . \esc_js($plugin_file) . '\']");
        if (row) {
          row.classList.add("update");
        }
      });
    </script>';

    $updates       = get_site_transient('update_plugins');
    $noshadowclass = isset($updates->response[$plugin_file]) ? 'ionos-plugin-noshadow' : '';

    $brand = Tenant::get_slug();

    $plugin_slug = dirname($plugin_file);
    // If the plugin is a single file in the root, dirname returns '.', so check for that
    if ('.' === $plugin_slug) {
      $plugin_slug = str_replace('.php', '', $plugin_file);
    }

    printf(
      '<tr class="plugin-update-tr %s ionos-wpscan-notice" data-parent-slug="%s"><td colspan="4" class="plugin-update colspanchange %s"><div class="update-message notice inline %s notice-alt">%s %s. <a href="%s">%s.</a></div></td></tr>',
      _is_plugin_active($plugin_file) ? 'active' : 'inactive',
      \esc_attr($plugin_slug),
      \esc_attr($noshadowclass ?? ''),
      \esc_attr('notice-error'),
      \esc_html__('The vulnerability scan has found issues for', 'ionos-essentials'),
      \esc_html($plugin_data['Name']),
      \esc_url(admin_url('admin.php?page=' . $brand . '#tools')),
      \esc_html__('More information', 'ionos-essentials')
    );
  }

  public function get_lastscan()
  {
    $last_run = \get_transient('ionos_wpscan_last_scan');
    if (false === $last_run) {
      return false;
    }
    return human_time_diff($last_run, time());
  }

  public function get_error(): ?string
  {
    return $this->error;
  }

  public function maybe_send_email(): bool
  {
    if (empty(\get_option(IONOS_SECURITY_FEATURE_OPTION, [])[IONOS_SECURITY_FEATURE_OPTION_MAIL_NOTIFY])) {
      return false;
    }

    $user_knows_about = \get_option('ionos_wpscan_issues_sent_to_user') ?: [];

    $type_and_slugs = array_map(fn ($issue) => $issue['type'] . ':' . $issue['slug'], $this->get_issues());

    $unknown_slugs = array_diff($type_and_slugs, $user_knows_about);

    if (empty($unknown_slugs)) {
      return false;
    }

    \update_option('ionos_wpscan_issues_sent_to_user', $type_and_slugs);

    $unknown_names = [];
    foreach ($this->get_issues() as $issue) {
      $key = $issue['type'] . ':' . $issue['slug'];
      if (in_array($key, $unknown_slugs, true)) {
        $unknown_names[$key] = $issue['name'] ?? $issue['slug'];

        if (function_exists('ionos\essentials\loop\log_loop_event')) {
          \ionos\essentials\loop\log_loop_event('vulnerability_detected', [
            [
              'slug'  => $issue['slug'],
              'type'  => $issue['type'],
              'score' => $issue['score'],
              'name'  => $issue['name'] ?? $issue['slug'],
            ],
          ]);
        }
      }
    }

    $to      = get_option('admin_email');
    $subject = __('Important Security Notification: Vulnerability detected in your WordPress website', 'ionos-essentials');
    $message = $this->get_mail_content(array_values($unknown_names));
    $headers = ['Content-Type: text/html; charset=UTF-8'];

    \wp_mail($to, $subject, $message, $headers);
    return true;
  }

  private function get_new_middleware_data(): void
  {
    $middleware   = new WPScanMiddleware();
    $data         = $middleware->download_wpscan_data();

    if (empty($data) || ! is_array($data)) {
      $this->issues = [];
      $this->error  = $middleware->get_error_message();
      \set_transient('ionos_wpscan_issues', [], 5 * MINUTE_IN_SECONDS);
      return;
    }
    $data         = $middleware->convert_middleware_data($data);

    $next_run = (strpos(json_encode($data), 'UNKNOWN')) ? 5 * MINUTE_IN_SECONDS : 23 * HOUR_IN_SECONDS;

    \set_transient('ionos_wpscan_last_scan', time(), $next_run);
    \set_transient('ionos_wpscan_issues', $data, $next_run);

    $this->issues = $data;
  }

  private function is_update_available($slug): bool
  {
    $plugins_updates = \get_site_transient('update_plugins');
    $theme_updates   = \get_site_transient('update_themes');
    $updates         = array_keys(array_merge($plugins_updates->response ?? [], $theme_updates->response ?? []));

    $short_slugs = array_map(fn ($update) => basename($update, '.php'), $updates);

    return in_array($slug, $short_slugs, true);
  }

  private function get_installed_slugs(): array
  {
    $plugins = \get_plugins();
    $themes  = \wp_get_themes();

    $plugin_slugs = array_map(fn ($plugin) => basename($plugin, '.php'), array_keys($plugins));

    $theme_slugs = array_keys($themes);

    return array_merge($plugin_slugs, $theme_slugs);
  }

  private function get_mail_content(array $vulnerable_plugins): string
  {
    $tenant             = Tenant::get_slug();
    $mail               = '<p>' . __('Dear user,<br />We want to inform you that our recent vulnerability scan has detected one or more issues that require your attention:', 'ionos-essentials') . '</p>';
    $mail              .= '<ul>';
    foreach ($vulnerable_plugins as $plugin) {
      $mail .= '<li>' . $plugin . '</li>';
    }
    $mail .= '</ul>';

    $mail .= '<p>' . __('To ensure the safety and security of your website, we recommend reviewing the findings of the scan and taking appropriate actions. For more detailed information about the specific vulnerabilities identified, please visit the following link:', 'ionos-essentials');
    $mail .= '<br><a href="' . admin_url('admin.php?page=' . $tenant . '#tools') . '">' . admin_url() . '</a></p>';

    $mail .= '<p><a href="' . admin_url('admin.php?page=' . $tenant . '#tools') . '">';
    $mail .= __('Turn off notification here', 'ionos-essentials') . '</a></p>';

    $mail .= \sprintf(
      // Translators: %s is the tenant name.
      __('Your %s plugin team', 'ionos-essentials'),
      Tenant::get_label()
    );

    return $mail;
  }
}
